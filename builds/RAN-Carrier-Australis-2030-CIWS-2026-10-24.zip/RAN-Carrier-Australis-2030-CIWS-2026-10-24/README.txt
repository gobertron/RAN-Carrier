Australis 2030 — retractable CIWS build, 24 October 2026

Three CIWS mounts start hidden in covered deck-edge wells. Native engagement
animations open covers in 0.10 seconds and raise the turrets in another
0.30 seconds. Native CIWS firing is gated until the opening completes.
Retraction takes 1 second after the native idle/rest condition (over10seconds).
Actual engagement, firing and retraction still require an in-game test.

Close Sea Power and extract this ZIP into Downloads, then run:
python3 "$HOME/Downloads/RAN-Carrier-Australis-2030-CIWS-2026-10-24/tools/install_australis_2030.py" --remove
python3 "$HOME/Downloads/RAN-Carrier-Australis-2030-CIWS-2026-10-24/tools/install_australis_2030.py"

The remove step makes a verified backup of the previous Australis mod.
Enable RAN Australis 2030 Editor Prototype, restart Sea Power, create a new
blank mission, and select Australia > CVN > Australis. Air group starts empty
for your selected installed carrier-capable aircraft.

Test concealment at spawn, engage a hostile air/missile target, watch covers
open before the lift rises, confirm firing only after full deployment, and
check retraction after disengagement. Use a new mission for the new meshes.
RADF, Workshop, original assets and User Data are not edited.

Rollback: close Sea Power, run the installer with --remove, then restore the
previous RAN-Carrier-Australis-2030 folder from the verified backup into
Sea Power_Data/StreamingAssets. Keep the previous build ZIP available.

Source commit: 6bd0366bde6667178909198f43b0ed68c24c355f
SHA256 inventory: BUILD-MANIFEST.json
