RAN Australis 2030 — installable build 2026-10-24

Original independent carrier: three bow + two port-waist steam catapults,
four helicopter/VTOL pads, four lifts and 99-aircraft design capacity.
Air group starts empty for your selected installed carrier-capable aircraft.
Native eligibility covers Plane/VTOL/STOL on rolling lanes and Helicopter/VTOL
on vertical pads; actual aircraft geometry and flight cycles need game testing.
The game model is the actual current mesh, not the earlier photoreal concept art.

INSTALL (Linux / fish-compatible commands)
1. Close Sea Power.
2. Extract this ZIP into your Downloads folder.
3. In a terminal run:
python3 "$HOME/Downloads/RAN-Carrier-Australis-2030-2026-10-24/tools/install_australis_2030.py" --remove
python3 "$HOME/Downloads/RAN-Carrier-Australis-2030-2026-10-24/tools/install_australis_2030.py"
4. Enable RAN Australis 2030 Editor Prototype in Mod Manager, restart Sea Power,
   open a new blank mission and select Australia > CVN > Australis.
5. Select your air group in the game. No aircraft pack is required by this mod.

The installer verifies stock references and all 38 package files. --remove
makes a verified backup of the previous Australis mod before withdrawal.
RADF, Workshop, original game files and User Data are not edited.
Existing installations are backed up to ~/Downloads/RAN-Carrier-Australis-2030-backups.

ROLLBACK
Close Sea Power, run the installer with --remove, then restore the previous
RAN-Carrier-Australis-2030 folder from the verified backup into StreamingAssets.

Source: https://github.com/gobertron/RAN-Carrier/tree/feature/australis-2050-concept
Build source: e04142174e9e3ee41dd5b5dcf85d385133de5cf3
Model revision: 64724edac9bc
SHA256 inventory: BUILD-MANIFEST.json
