# Australis enclosed-deck controller — experimental 0.5.1

This original AnchorChain/Harmony addon operates **only** `ran_cvn_australis_2030`.
It is compiled, not yet tested inside Sea Power. Do not treat static validation
or the browser animation as proof of in-game flight/combat behaviour.

The carrier has inboard bays with independent flush sliding covers. CIWS,
30 mm guns, defensive launchers and chaff use enclosed platforms. VLS cells
stay recessed and their covers slide fore/aft. Nulka and lasers remain visual
concepts; this addon does not invent working Nulka or laser weapons.

Sequence:

1. A weapon requests firing; new aircraft launch spawning and recovery claims pause.
2. Aircraft already committed to the deck finish their native operations.
3. Once clear, covers open then platforms rise in **0.75 simulation seconds**.
4. Actual emitted gun rounds, CIWS rounds, missiles and chaff reset a shared
   **300 simulation second** hold. Merely tracking a target does not reset it.
5. Platforms lower and covers close over **10 seconds**. A new firing request
   reverses this motion without releasing the flight lock.
6. New launches and recoveries resume only after fully stowed. Pending aircraft
   remain queued/in holding; no native reservations are deleted or fabricated.

The deploy is under one second **after committed aircraft clear**, not an
instantaneous interruption of an aircraft already landing. All bays operate as
one group. Simulation pause/time compression applies to the timer. A request
that produces no shot times out 300 seconds after reaching the deployed pose.

Installation (Sea Power closed):

- Install the official [AnchorChain preloader](https://github.com/SeaPower-Modders/AnchorChain/releases).
  Follow its [installation guide](https://github.com/SeaPower-Modders/AnchorChain/blob/main/Writerside/topics/Install-Anchor-Chain.md).
- Subscribe to [AnchorChain Workshop](https://steamcommunity.com/sharedfiles/filedetails/?id=3380210757)
  and enable it. On Linux/Proton, the Windows preloader must actually load;
  use the framework's Proton guidance rather than assuming subscription is enough.
- Withdraw the earlier Australis version with the command below, then install:

```fish
python3 "$HOME/Downloads/RAN-Carrier-Australis-test/tools/install_enclosed_deck.py" --remove
python3 "$HOME/Downloads/RAN-Carrier-Australis-test/tools/install_enclosed_deck.py"
```

The installer changes only our mod folder and
`Sea Power_Data/StreamingAssets/RAN.Australis.DeckController.dll`.
It backs up existing copies. It reads framework/stock/Workshop references without
editing them. Missing framework or a different game DLL stops installation.
The old installer also refuses this package without the matching addon DLL.

Restart the game, enable AnchorChain and Australis, and inspect
`StreamingAssets/RAN-Australis-DeckController.log` for `Installed 15 audited hooks`.
`NOT ACTIVE` means the runtime must not be considered operational. A model-binding
failure keeps that carrier's weapons/aviation gated; report the log before continuing.
To withdraw both parts, rerun the first command. Backups are retained in Downloads.

Audited game scripts SHA-256:
`3b193dcb71fcbae2f8ede15484223b139948e2b9bd3ae66fc7d45db104350297`.
Game/Unity DLLs and framework binaries are not redistributed. Build dependencies:
official .NET SDK 8.0.408, AnchorChain V1.1.0 dev archive, BepInEx 5 Harmony reference.

Build using `tools/build_deck_controller.py --help`; run
`tools/test_deck_controller.py --sdk /path/to/dotnet` for policy checks.
`BayData.cs` is generated from `australis-2030/enclosed_deck.py`.

Required first in-game QA: blank editor load; exact transform names resolve;
weapon effects/spawns follow the raised platforms; launch queue survives a
combat request; committed launch/recovery clears before opening; recovery holds
until closed; chaff/salvo accounting; 300 seconds after the last actual shot;
pause/compression; save/load; carrier destruction and multiple carriers.
If binding or mandatory hooks fail, do not bypass the installer version check.
