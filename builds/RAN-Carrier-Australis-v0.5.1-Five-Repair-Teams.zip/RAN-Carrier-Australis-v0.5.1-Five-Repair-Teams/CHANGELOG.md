# Change history

## v0.5.1 — Five repair teams and dedicated ship page

- Configure five native repair/damage-control teams with General.NumberOfDCTeams=5.
- Validate the generated native setting and matching combat-fit metadata.
- Retain v0.5.0 hull, internal arrangement, aircraft routes and defensive fit.
- Add a dedicated Australis ship page with current exterior renders, internal cutaway, measured plan, specifications, installation and QA status.
- Supply a new paired installer and archive; retain earlier numbered versions.
- Live repair-team counts, repair behaviour, combat and flight operations still need in-game testing.

## v0.5.0 — Hull and internal-space correction

- Rebuild the upper hull around the full height of four internal lift trunks and all defensive weapon wells.
- Rebalance 1.2 m of upper-deck breadth toward starboard while retaining 82 m overall beam. Keep the original underwater mesh and all lift/catapult/helipad/arresting-wire positions.
- Add an original 280 × 50 × 8 m hangar floor and three-sided lift trunks to the game model.
- Check 36 mixed folded reference parking boxes: 24 large, eight compact/UAV and four rotary wing, with a clear 6 m port towing spine.
- Reserve 151 accommodation envelopes for 5,800 berths, plus hotel/medical/workshop, machinery, magazines, catapult plant and aviation-fuel space.
- Move three decoy bays clear of the hangar/lift trunks and move the aft starboard laser reservation inside the shell.
- Validate against actual triangulated OBJ geometry during build and installation; reproduce the old hull's failed clearances as regression tests.
- Supply a labelled internal cutaway, measured plan, exact current-package exterior viewer and versioned standalone installer.
- Internal reservations are geometric blockouts. Actual aircraft towing, lift animation, 63-plane deck parking, complete 99-aircraft operations, structural loading and stability remain unverified.

## v0.4.0 — Helipad clearance layout

- Put pad 1 ahead of the forward lift, pad 2 beside the main tower, pad 3 beside the rear tower and pad 4 aft of the rear tower.
- Keep all four 21 m pad footprints clear of the catapult tracks, full 25 × 30 m aircraft staging/rollout envelopes, recovery strip, towers and lifts.
- Move the obstructing forward VLS bay and two small decoy positions aft; retain 80 cells and the defensive weapons fit.
- Check fully open covers and laser hatches as well as the closed bay/well footprints.
- Reroute fixed-wing taxi centre-lines around the helipad circles. Full airframe swept turns remain subject to game QA.
- Update pad-to-elevator assignments and taxi/recovery routes; interlock the two aft spots sharing lift 4.
- Check a full 25 m aircraft span along the arrested-recovery lane, not just its painted width.
- Preserve the v0.3.0 lift positions, catapults and arresting-wire geometry.
- Static clearance and installer tests required; rotor swept paths and in-game flight cycles remain unverified.

## v0.3.0 — Lifts around the main tower

- E1 ahead of tower 1; E2/E3 inline on its port side; E4 between the towers.
- Keep four full-size 22 × 26 m internal platforms and the existing nine-degree recovery strip.
- Preserve all four arresting-wire meshes exactly as exported in v0.2.0.
- Shift the three bow lanes and two waist lanes; move vertical pads forward and interlock vertical launches with all five catapults.
- Reposition port defensive bays clear of the shifted bow rollout; separate the fully open bay covers.
- Update aircraft routes, controller transforms, actual-package preview and versioned installer.
- Static layout/installation checks pass; in-game operations remain unverified.

## v0.2.0 — Internal aircraft lifts

- Move four 22 × 26 m lift platforms inside the upper hull, in two pairs at z=-110/-140 m and x=±12.5 m.
- Cut matching openings through the flight deck; retain flush platform surfaces.
- Update aircraft spawn/ride centres and taxi routes for the new lift positions.
- Relocate two visual Nulka bays clear of the lift wells and update the controller transforms.
- Remove the previous 109 m overhang width; overall deck beam remains 82 m.
- Refresh the preview from this release's actual OBJ/INI files.
- Static checks and installer tests required; in-game deck operations remain pending.

## v0.1.0 — Enclosed weapon bays

- Original enclosed-bay prototype with an AnchorChain deck controller.
- 0.75 s deployment after committed aircraft clear, 300 s last-shot hold, 10 s stow.
- Gate new launch/recovery requests until stowed.
- Compiled and locally tested; in-game QA pending.

## Version policy

Each completed logical change gets its own commit, changelog entry and numbered build.
Fixes increment the patch version; layout/features increment the minor version.
Keep earlier installers/archives for rollback. Publish matching Git tags to the
user-selected repository. The current publication target is GitHub gobertron/RAN-Carrier.
