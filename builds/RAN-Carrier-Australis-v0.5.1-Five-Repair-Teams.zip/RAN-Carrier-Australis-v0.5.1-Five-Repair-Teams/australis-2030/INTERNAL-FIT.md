# Australis v0.5.0 — internal fit

The upper hull now contains the complete lift-trunk and defensive-bay
reservations. The game model includes an original hangar floor and three-sided
lift-trunk walls. The cutaway adds labelled space envelopes for planning;
its coloured aircraft, rooms and machinery are not detailed game objects.

The 370 m length, 82 m overall deck beam and original underwater mesh are
retained. Upper-deck breadth is redistributed 1.2 m toward starboard; a port
station preserves waist-catapult staging clearance. All four lift platforms,
five catapults, four pads and arresting wires retain their v0.4.0 positions.

| Reservation | Measured / planned value |
|---|---:|
| Hangar length × width × clear height | 280 × 50 × 8 m |
| Hangar floor / ceiling | 11.8 / 19.8 m above waterline |
| Gross hangar floor area | 14,000 m² |
| Hangar area outside lift-trunk reservations | Approximately 12,275 m² |
| Reference parked-aircraft boxes | 36 |
| Reference mix | 24 large folded, 8 compact/UAV, 4 folded rotary wing |
| Longitudinal port towing spine | 6 m clear width |
| Embarked personnel / planning berths | 5,300 / 5,800 |
| Berthing room envelopes / floor area | 151 / 23,280 m² |
| Separate hotel, medical and workshop floor area | 5,488 m² |
| Gross aviation-fuel reservation | 13,316.8 m³ |
| Minimum lift-trunk / hull clearance | 0.488 m |
| Minimum weapon-well / hull clearance | 1.115 m |
| Minimum future laser reservation / hull clearance | 0.543 m |

Reference parking boxes include local allowance: large folded 12 × 20.5 m,
compact/UAV 9 × 11 m, folded rotary wing 9 × 14 m. They fit without overlap
with other boxes, the lift trunks, weapon wells or the towing spine. This
does not guarantee a hangar full of any chosen aircraft type. Aircraft still
need turning room, handling trials, folding and suitable installed models.

Accommodation envelopes provide at least 4 m² per planned berth and 2.6 m
headroom. Separate hotel/service envelopes are reserved. Bunks, doors,
stairways, evacuation, ventilation and human circulation are not engineered.
Machinery, power, magazines and distributed fuel tanks have distinct zones;
actual machinery, piping, magazine protection and tank subdivisions remain
design work. A planning calculation of 85% usable tank volume at 0.8 t/m³
allows the existing 9,000 t aviation-fuel target; this is not measured fuel
capacity or structural verification.

`tools/internal_fit.py` measures sections through the actual triangulated game
OBJ. Build and installer validation test complete reserved heights, room and
bay collisions, parking, occupancy density and recorded area/volume. The
regression test reproduces the former hull's failures and compares underwater
vertices directly with v0.4.0. These checks do not establish structural
strength, stability, seakeeping or hydrodynamic performance.

The 99-aircraft figure remains the game/design capacity: 36 mixed reference
hangar places plus a proposed 63 on deck. The complete 99-aircraft parking
and flight cycle has not been verified. All native aircraft types and broad
carrier eligibility remain enabled. Lift platforms remain static; trunk space
is present, but native lowering animation is not implemented.

Three SRBOC positions move clear of the internal arrangement. The aft starboard
laser hatch moves to physical (X,Z) = (27,-163) m. The defensive fit, 80 VLS
cells and AnchorChain deployment/flight-lock policy are retained. Lasers remain
visual reservations. Sea Power loading, firing and flight operations need QA.

## Files and rollback

- `internal-preview/viewer/australis_v0.5.0_internal_cutaway.html`: self-contained rotatable planning cutaway.
- `internal-preview/australis_v0.5.0_internal_plan.png`: measured hangar plan and forward-lift section.
- `current-game-preview/viewer/`: exact current-package exterior viewer and matching photos.
- `../builds/install-ran-australis-v0.5.0.sh`: paired carrier/controller installer with verified backups.
- The immutable v0.4.0 installer and source snapshot remain available for rollback.

Run the installer with Sea Power closed. It reads stock references and only
updates this carrier and its named controller. Use a fresh mission/carrier
after installation. The current publication target is GitHub gobertron/RAN-Carrier. v0.5.1 adds five native repair teams without altering the hull or reference parking geometry.
