"""Original Australis design coordinates, in physical metres.

Deployment is implemented by the AnchorChain addon. No native animation
implementation or private game-DLL audit is distributed here.
"""
CIWS_POSITIONS_M = ((-20.0,19.0,158.0),(30.0,19.0,-69.0),(-25.0,19.0,-158.0))
