# HMAS Australis — independent RAN carrier

**Sea Power · v0.5.1 · fictional 2030–2050 carrier concept**

Australis is an original Australian nuclear-carrier game design with a clean,
faceted hull, two islands, five steam catapults and four helicopter/VTOL spots.
This version adds **five native repair/damage-control teams** to the corrected
upper hull and internal-space arrangement.

![Australis exterior — current installable model](current-game-preview/previews/australis_2030_current_starboard.png)

These are renders of the actual package model and labelled planning overlays.
They are not gameplay screenshots or photographs of a real vessel.

[Exterior photos and rotatable 3D](viewer/australis_2030_3d.html) ·
[Internal cutaway in 3D](internal-preview/viewer/australis_v0.5.1_internal_cutaway.html) ·
[Measured internal plan](internal-preview/australis_v0.5.1_internal_plan.png) ·
[Version history](../CHANGELOG.md)

Download either self-contained HTML viewer and open it in your browser.
GitHub displays HTML source rather than running the viewer in its file page.

## Ship at a glance

| Feature | Current configuration or design target |
|---|---|
| Name / role | HMAS Australis; Royal Australian Navy CVN concept |
| Length | 370 m |
| Overall flight-deck beam | 82 m, including the internal lifts |
| Maximum waterline beam / draft | Approximately 41 m / 11.5 m |
| Full-load displacement | 112,000 t concept target; not a measured structural weight |
| Propulsion | Nuclear game configuration / design target |
| Aircraft capacity | 99 game/design places; complete operating cycle unverified |
| Hangar | 280 × 50 × 8 m; 14,000 m² gross floor |
| Hangar reference packing | 24 large folded + 8 compact/UAV + 4 folded rotary wing |
| Embarked people / planning berths | 5,300 / 5,800 |
| Accommodation | 151 room envelopes, 23,280 m² of reserved berthing floor |
| Repair teams | **5 native damage-control teams** |
| Launch system | Three bow + two port-waist steam CATOBAR tracks; 95 m each |
| Recovery | Nine-degree port landing axis with four wire indications |
| Aircraft lifts | Four internal 22 × 26 m platforms |
| Islands | Larger forward/main island; smaller rear island with wraparound glazing |
| Vertical spots | Four 21 m helicopter/VTOL reference circles |

## Exterior design

The upper hull encloses the lift trunks and defensive weapon wells. It meets
the flight deck without outboard weapon shelves. Rebalancing 1.2 m of upper
deck breadth toward starboard provides internal clearance while retaining
82 m overall beam. The original underwater mesh is preserved.

The approved lift positions, launch tracks, helicopter spots and arresting
gear retain their v0.5.0 geometry. The forward lift is ahead of the main
tower; two lifts line its port side; the fourth sits between the towers.

![Port-waist exterior](current-game-preview/previews/australis_2030_current_port_waist.png)

![Flight deck — current launch, recovery, lift and helipad layout](current-game-preview/previews/australis_2030_current_deck.png)

![Bow and upper-hull lines](current-game-preview/previews/australis_2030_current_bow.png)

## Internal design

![Internal cutaway — coloured space reservations](internal-preview/previews/australis_v0.5.1_cutaway.png)

The cutaway uses the native hull with its starboard side and flight deck
removed for inspection. Coloured boxes reserve space; they are not detailed
cabins, aircraft or machinery. Toggle its 3D layers to inspect the lift trunks,
hangar, accommodation, plant, fuel and magazine reservations.

![Measured hangar plan and forward-lift hull section](internal-preview/australis_v0.5.1_internal_plan.png)

| Space check | Current result |
|---|---:|
| Minimum lift-trunk / shell clearance | 0.488 m |
| Minimum defensive weapon-well / shell clearance | 1.115 m |
| Minimum future laser-space / shell clearance | 0.543 m |
| Hangar clear height | 8 m |
| Mixed reference hangar slots | 36 |
| Port towing spine | 6 m clear width |
| Planning berths | 5,800 |
| Separate hotel / medical / workshop floor | 5,488 m² |
| Gross aviation-fuel reservation | 13,316.8 m³ |

The reference parking boxes include local allowance: 12 × 20.5 m for large
folded aircraft, 9 × 11 m for compact/UAV aircraft and 9 × 14 m for folded
rotary wing. Actual folding, towing turns and handling depend on the aircraft.
The proposed 63-aircraft flight-deck allocation and complete 99-aircraft cycle
are still unverified. [Full internal-fit report](INTERNAL-FIT.md).

## Five repair teams

The vessel uses the native game setting:

```ini
[General]
NumberOfDCTeams=5
```

This sets the ship's normal damage-control team allowance. Teams are allocated
through the game's damage-control system; availability changes as teams are
assigned or disabled. This does not change native repair rates or grant
instant repairs. Test with a fresh undamaged carrier in a new mission and
confirm five teams in the damage-control panel. Saved missions may preserve
earlier allocations. The configuration is validated; live behaviour still
needs an in-game check.

## Aviation

- Five rolling launch lanes and arrested recovery accept installed carrier-capable Plane, VTOL and STOL types.
- The four vertical points accept Helicopter and VTOL types.
- No carrier-specific class whitelist or size, role or loadout exclusions are applied.
- The air group starts empty so you can select your installed aircraft without an aircraft-pack dependency.
- The four helipads sit ahead of the forward lift, beside the main tower, beside the rear tower and behind the rear tower.
- Helipad footprints clear the catapult reference aircraft envelopes, lifts, tower bases and fully open weapon covers.
- Aircraft contact positions match the deck, pads and lift surfaces.
- Aviation stores have a finite 6,000,000-point reserve; actual endurance depends on aircraft and loadouts.

Broad eligibility does not establish physical compatibility with every mod
aircraft. Swept taxi paths, rotor clearance, loadouts and mixed deck cycles
require testing. Lift trunks have physical space and walls, but the prototype
lift platforms remain static. Conservative launch/recovery interlocks remain.

## Defensive weapons and sensors

| Fit | Current representation |
|---|---|
| VLS | Four defensive banks, 80 cells; stock RIM-7M compatibility proxies |
| Self-defence missile mounts | Two eight-round ESSM-form and two 21-position RAM-form mounts; stock Sea Sparrow proxies |
| Close-in defence | Three Phalanx-form CIWS mounts and two 30 mm guns |
| Radar | Conformal island arrays with declared stock search, surface-search, approach and fire-control proxies |
| Electronic warfare | ESM, defensive jamming and one original offensive-ECM game profile |
| Decoys | Eight SRBOC positions, four visual Nulka positions and two stock Nixie references |
| Lasers | Four future-space reservations / visual hatches; functional laser weapons are not implemented |

RIM-66E and RGM-109 are absent from this fit. Modern equipment names describe
design roles; stock proxies keep their declared stock behaviour. In particular,
the RAM-form launchers currently use Sea Sparrow guidance, not RAM guidance.

The original AnchorChain controller raises the enclosed defensive bays in
0.75 simulation seconds after committed aircraft clear. It holds them ready
for 300 seconds after the last actual shot, then stows over 10 seconds. New
aviation operations remain gated until the bays close. This behaviour has
local policy checks but still needs in-game combat/flight-lock testing.

## Install v0.5.1

Close Sea Power. Download the numbered installer, then run it with Bash even
when your interactive shell is fish:

```bash
curl -fL 'https://raw.githubusercontent.com/gobertron/RAN-Carrier/feature/australis-2050-concept/builds/install-ran-australis-v0.5.1.sh' -o "$HOME/Downloads/install-ran-australis-v0.5.1.sh"
bash "$HOME/Downloads/install-ran-australis-v0.5.1.sh"
```

[Installer](../builds/install-ran-australis-v0.5.1.sh) ·
[Source/build ZIP](../builds/RAN-Carrier-Australis-v0.5.1-Five-Repair-Teams.zip)

The experimental enclosed-deck fit requires the official AnchorChain preloader
and framework. Use the [official AnchorChain releases](https://github.com/SeaPower-Modders/AnchorChain/releases)
and [Workshop framework](https://steamcommunity.com/sharedfiles/filedetails/?id=3380210757).
The installer checks the supported game version and prerequisites before
changing this carrier. It keeps verified backups and writes a copyable log.

Enable AnchorChain and the Australis mod, restart Sea Power and place a fresh
Australia → CVN → Australis in a blank mission. Choose aircraft in the editor.
Check the five-team allowance in the damage-control panel.

Useful installer options:

```bash
bash "$HOME/Downloads/install-ran-australis-v0.5.1.sh" --check
bash "$HOME/Downloads/install-ran-australis-v0.5.1.sh" --remove
```

Only the independent carrier folder and its named controller are installed.
RADF, Workshop files, original game files and User Data are not edited.
Use the retained v0.5.0 installer or a verified carrier/controller backup to
roll back. [Detailed test and rollback steps](GAME-TEST.md).

## Validation and remaining work

Build checks measure the actual triangulated OBJ and generated native INI.
They cover complete internal reservations, parking-box collisions, berth
density, aircraft reference envelopes, native routes, materials, mounts,
ammunition references and the five-team setting. The old hull's failed
clearances are reproduced by regression tests. Earlier underwater vertices
are compared directly. Installer simulations check dependencies, installation,
upgrade, backups, idempotence, withdrawal and protected-folder preservation.

Remaining checks are live Mission Editor loading of this revision, five-team
display/allocation, repair behaviour, firing, bay animation, aviation locking,
aircraft turns and the full 99-aircraft cycle. Structure, stability and
hydrodynamics are not verified by these geometry checks.

## Version history

| Version | Main change |
|---|---|
| **0.5.1** | Five native repair teams and this dedicated ship page |
| 0.5.0 | Upper-hull correction, internal lift trunks, hangar and measured space plan |
| 0.4.0 | Four clear helipads around the lifts and towers |
| 0.3.0 | Approved lift arrangement around the main tower |
| 0.2.0 | Internal-lift prototype |
| 0.1.0 | Enclosed weapon bays and original AnchorChain controller |

Earlier numbered artifacts are retained. [Complete changelog](../CHANGELOG.md).

## Credits and source

Hull, islands, deck layout, weapon housings, solid-colour textures, space
reservations, renders and controller are original project work. Ford and
Zumwalt concepts inform the design direction; this is not an exact simulation
of either ship. Sea Power and AnchorChain are runtime dependencies. No RADF
model, Workshop asset, proprietary game DLL or private game-analysis dump is
included in this ship's published source.

[Game package](../game-mod/RAN-Carrier-Australis-2030/) ·
[Authoring model](model/source/) · [Builder](build.py) ·
[Native package builder](../tools/build_australis_2030_mod.py) ·
[Internal validator](../tools/internal_fit.py) ·
[Design basis](DESIGN-BASIS.md)
