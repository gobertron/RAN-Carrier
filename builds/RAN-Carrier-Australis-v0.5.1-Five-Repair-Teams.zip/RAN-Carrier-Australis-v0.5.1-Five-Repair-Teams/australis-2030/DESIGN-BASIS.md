# Australis 2030 — v0.5.0 design basis

Current dimensions are 370 m overall, 82 m overall flight-deck beam, approximately
41 m maximum waterline beam and 11.5 m draft. The unchanged immersed model
estimates 112,402 t displacement in seawater against a 112,000 t concept mass
budget. Actual lightship weight, centre of gravity and stability are unverified.

The [internal fit report](INTERNAL-FIT.md) supersedes earlier hangar, lift and
bay layouts. The current 280 × 50 × 8 m hangar has 36 mixed folded reference
parking boxes. The 63-aircraft flight-deck allocation and full 99-aircraft
operating cycle remain unverified. Accommodation reserves 5,800 berths for
5,300 embarked people in 151 room envelopes with separate hotel/service space.
These are measured space reservations, not a completed ship arrangement.

Three 95 m bow catapults and two 95 m port-waist catapults retain their v0.4.0
positions. The waist tracks head six degrees to port; arrested recovery remains
nine degrees to port. Four 22 × 26 m internal lifts retain their approved
positions around the two towers. Helipads sit ahead of the forward lift, beside
the main tower, beside the aft tower and aft of the aft tower. All pads remain
off the catapult reference envelopes. Actual taxi turns, rotor clearance and
mixed flight cycles require in-game testing.

The original mass allocation remains a concept budget: structure 42,000 t;
machinery 12,500 t; ship/aviation outfit 15,000 t; combat/electronics 5,000 t;
aviation fuel 9,000 t; aircraft/wing equipment 6,500 t; ordnance/stores 5,500 t;
water/fluids 4,500 t; personnel/effects/provisions 2,500 t; allowance 9,500 t.
The rebuilt upper hull has not been weighed structurally. Static volume and
budget agreement is only a scale check.

## Equipment targets and current game representation

Stock proxies retain their stock guidance, range and performance. Modern
names describe desired equipment, not performance silently assigned to it.

| Equipment target | Positions | Current native representation |
|---|---:|---|
| Defensive VLS | 80 cells, four main-deck edge banks | Mk41; 80 stock RIM-7M defensive proxies total; vertical-launch behaviour needs game QA |
| ESSM self-defence | Two eight-round mounts | Mk29; 16 stock RIM-7M Sea Sparrows total |
| RIM-116 RAM-form launchers | Two 21-position mounts | Original launcher; 42 stock RIM-7Ms total; SARH, **not RAM guidance** |
| Phalanx | Three | Stock Mk15 Block 1; 12,000 shared rounds |
| Mk46-style 30 mm remote guns | Two | Original 200-round/min adapter; stock British 30 mm ammunition; 2,000 shared rounds |
| EASR/SPY-6-style search | Main-island panel fit | Stock SPY-1A search proxy |
| SPY-3-style multifunction faces | Conformal island panels | Original geometry; stock SPG-62/Mk95 fire-control proxies |
| Surface search / approach control | Island-mounted | Stock SPS-67 / SPN-43 |
| SLQ-32/SEWIP-style passive warning | Main island | Stock AN/SLQ-32 ESM |
| Defensive EW | Main island | Stock AN/SLQ-32 jammer |
| Offensive EW | One logical installation | Original game-balance values: 250 km, 30 kW, gain 12, 60° cone; **not measured SEWIP specifications** |
| Mk36 SRBOC | Eight | Stock chaff system and late ship chaff |
| Nulka active decoy | Four | Original visible launchers; hovering active-decoy behaviour unimplemented |
| Nixie torpedo decoy | Two stern attachments | Stock SLQ-25/Nixie countermeasure |
| Retracting defensive lasers | Four hatches | Visual study; operational weapon and game deployment animation unimplemented |

The native fit has 21 weapons, 11 sensors and two towed decoys. RIM-66E and
RGM-109 are absent from the magazines, and the native anti-surface capability
rating is zero. Self-defence guns and stock Sea Sparrow can still engage
surface targets where the game permits; no dedicated ship strike missiles
are carried. VLS banks are centred at (-32,-135), (32,140), (-32,-92),
(23,-148) metres. The four missile housings also sit on the main deck, with
eight matching no-parking zones. Weapon and decoy wells are enclosed inside the upper hull.

Five guns have original moving yaw bodies and elevation barrels. Missile/decoy bays and covers use the paired AnchorChain controller. Laser hatches remain static visual concepts. Port/starboard weapon
sectors face outboard; blast, fragmentation and arc masking are unverified.
Zumwalt's former AGS and an unverified hypersonic installation are not added.

## Aircraft ammunition and deck contact

The finite aviation reserve is **6,000,000/6,000,000 ammo points**, five times
the former value. There are no individual accountable-category limits. A
planning allowance of 99 aircraft × four sorties × 15,000 points fits within
that reserve; actual endurance depends on selected aircraft and loadouts.
These are game supply points, not a direct mass conversion. Stock F-14A and
A-7E gun magazines retain 675 and 1,000 rounds respectively, with stock
countermeasure capacities. No aircraft files are overridden. Aircraft must
use an armed loadout and complete preparation/rearming between sorties.

Main-deck taxi, launch and fixed-wing recovery contact heights are 22 m,
matching the exported deck. Lift and helicopter contacts match their 22.002 m
platform and painted-pad surfaces. The two-millimetre allowance prevents
coplanar flicker at overlapping deck edges. Ordinary deck markings rise 4–8 mm above
the deck, stowed deflectors are within 2 mm of it and closed laser hatches
are within 2 mm of the deck. Visible wires rise 3 cm and launch shuttles 6 cm. These details
replace the former raised paint, 8 cm pads and 20.5 cm lift steps.
Sea Power applies each aircraft's
GroundPivot correction itself. The former 16 cm extra main-deck offset is
removed. This aligns the declared contact plane; tyre appearance still
requires in-game inspection for each aircraft type.

## Gun error correction

The supplied game DLL's ObjectBaseLoader loads ordinary gun barrels using
NumberOfGuns and Gun1..GunN. The previous 30 mm sections used Gun=Dummy,
which is a supported CIWS pattern but leaves the normal-gun barrel null.
WeaponSystemGun.AlignTurret immediately dereferences that barrel. Both 30 mm
guns now supply NumberOfGuns=1 and a registered original Gun1 mesh. All five
guns resolve their mount, elevation base and barrel through native submodels
and parent links. The validator checks these exact engine-consumed keys.
This traces and corrects the reported failure; live firing remains pending.

## Reference basis

- [Naval Aviation News, Winter 2022](https://navalaviationnews.navy.mil/Portals/59/Documents/2022_00Winter.pdf): Ford dimensions, crew, air group and ESSM/RAM/CIWS families.
- [Raytheon Zumwalt systems](https://www.rtx.com/raytheon/what-we-do/sea/zumwalt-class-destroyer): peripheral VLS, automation and integrated power concepts.
- [NAVSEA Zumwalt SM-2 trial](https://www.navsea.navy.mil/Media/News/Article/2386284/uss-zumwalt-successfully-completes-first-standard-missile-shot/): Mk57/Standard Missile relationship.
- [Northrop Grumman SEWIP](https://www.northropgrumman.com/what-we-do/mission-solutions/electronic-warfare/surface-electronic-warfare-improvement-program-sewip): electronic-attack role, not our simulation numbers.
- [NAVSEA Australian Nulka collaboration](https://www.navsea.navy.mil/Media/News/Article/1617036/royal-australian-navy-delegation-visits-nswc-dahlgren-division-in-the-wake-of-r/): Australian/U.S. active offboard decoy development.
- The supplied Sea Power copy provides schema/profile references. No stock/Workshop model, texture, DLL or INI bytes are redistributed.
