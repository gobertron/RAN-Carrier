# HMAS Australis

**Current release: v0.5.1 — five native repair teams.**

[Open the complete ship page: exterior, interior, specifications, aviation, weapons and installation](SHIP.md).

![Australis current exterior](current-game-preview/previews/australis_2030_current_starboard.png)

[Exterior 3D](viewer/australis_2030_3d.html) · [Internal 3D](internal-preview/viewer/australis_v0.5.1_internal_cutaway.html) · [Internal fit report](INTERNAL-FIT.md).

The upper hull, hangar and lift-trunk geometry is unchanged from v0.5.0. Five repair teams are configured using the native General.NumberOfDCTeams key. In-game QA and the full 99-aircraft operating cycle remain unverified.
