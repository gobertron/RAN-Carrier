#!/usr/bin/env python3
"""Exact native hull with clearly labelled internal planning-volume overlays."""
from pathlib import Path
import sys,json,re,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'australis-2030')]
from build_current_game_preview import load_current_mesh,PACKAGE
from generate_source_models import Mesh
import build_3d_viewer as viewer
from render_current_views import _render
from internal_fit import validate_arrangement,HullEnvelope

PALETTE={'hull':'#667d8c','hangar':'#78b5c0','aircraft':'#d7e5e4','lift':'#53c5d5',
         'weapon':'#e89d62','laser':'#c8a7e0','accommodation':'#d6ba77','machinery':'#6db9a0',
         'fuel':'#cba456','magazine':'#d9808b','hotel_service':'#8e9fd0','aviation_service':'#9bb9c8'}
LABELS={'hull':'Native port hull and deck outline','hangar':'Hangar envelope (wireframe)',
        'aircraft':'36 folded reference aircraft slots','lift':'Four lift trunks','weapon':'25 weapon/decoy wells',
        'laser':'Four future laser reservations','accommodation':'5,800 berths: room envelopes',
        'machinery':'Machinery and power zones','fuel':'Aviation fuel reservation',
        'magazine':'Aviation magazine zones','hotel_service':'Hotel / medical / workshop zones',
        'aviation_service':'Catapult machinery reservation'}

def box(mesh,name,b,material):
    a,c,d,e,f,g=b
    mesh.box(name,(a+c)/2,(d+e)/2,(f+g)/2,c-a,e-d,g-f,material)

def beam(mesh,name,a,b,material,r=.12):
    a,b=np.array(a),np.array(b);d=b-a
    d=d/np.linalg.norm(d);u=np.cross(d,(0,1,0))
    if np.linalg.norm(u)<1e-5:u=np.cross(d,(0,0,1))
    u=u/np.linalg.norm(u)*r;v=np.cross(d,u)
    points=[p+s*u+t*v for p in (a,b) for s,t in ((-1,-1),(1,-1),(1,1),(-1,1))]
    mesh.add(name,points,[[0,3,2,1],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]],material)

def wire_box(mesh,name,b,material):
    a,c,d,e,f,g=b
    pts=[(x,y,z) for x in (a,c) for y in (d,e) for z in (f,g)]
    for i,p in enumerate(pts):
        for bit in (1,2,4):
            j=i^bit
            if j>i:beam(mesh,f'{name} edge {i}-{j}',p,pts[j],material)

def drawing(data,hull,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    bg='#101e2a';fg='#dce9ec';muted='#a6bdc8'
    plt.rcParams.update({'font.family':'DejaVu Sans','text.color':fg,'axes.labelcolor':muted,
                         'xtick.color':muted,'ytick.color':muted,'axes.edgecolor':'#4e6877'})
    fig=plt.figure(figsize=(16,10.5),facecolor=bg)
    gs=fig.add_gridspec(2,2,height_ratios=(1,1.5),width_ratios=(1.6,1),hspace=.38,wspace=.24)
    plan=fig.add_subplot(gs[0,:]);section=fig.add_subplot(gs[1,0]);notes=fig.add_subplot(gs[1,1])
    for ax in (plan,section):ax.set_facecolor(bg);ax.grid(alpha=.12,color=muted)
    hangar=data['hangar_bounds_m'];a,b,c,d,e,f=hangar
    plan.add_patch(Rectangle((e,a),f-e,b-a,facecolor='#1d3845',edgecolor=PALETTE['hangar'],lw=1.7))
    spine=data['hangar_towing_spine_bounds_m']
    plan.add_patch(Rectangle((spine[4],spine[0]),spine[5]-spine[4],spine[1]-spine[0],facecolor='#376c70',alpha=.55))
    for s in data['parking_slots']:
        a,b,c,d,e,f=s['bounds']
        plan.add_patch(Rectangle((e,a),f-e,b-a,facecolor=PALETTE['aircraft'],edgecolor=bg,lw=.6))
        label='L' if 'large' in s['note'] else 'R' if 'rotor' in s['note'] else 'U'
        plan.text((e+f)/2,(a+b)/2,label,ha='center',va='center',fontsize=7,color='#17303b')
    for s in data['spaces']:
        if s['category']!='lift':continue
        a,b,c,d,e,f=s['bounds']
        plan.add_patch(Rectangle((e,a),f-e,b-a,facecolor='#254e60',edgecolor=PALETTE['lift'],lw=1.3))
        plan.text((e+f)/2,(a+b)/2,s['name'].replace('Lift shaft ','E'),ha='center',va='center',fontsize=9,color=fg)
    plan.set(xlim=(-141,147),ylim=(-28,42),xlabel='Longitudinal position (m) — bow to the right',ylabel='Port  ←  X (m)  →  Starboard')
    plan.set_aspect('equal');plan.set_title('280 × 50 m hangar plan · 24 large folded + 8 compact/UAV + 4 folded rotor references',loc='left',fontsize=12,pad=12)
    z=54.;ys=np.linspace(-11.49,21.999,350);pairs=[(y,hull.section(float(y),z)) for y in ys];pairs=[(y,p) for y,p in pairs if p]
    shape=[(p[0],y) for y,p in pairs]+[(p[1],y) for y,p in reversed(pairs)]
    section.fill([p[0] for p in shape],[p[1] for p in shape],color='#273e4c',alpha=.8)
    section.plot([p[0] for p in shape+[shape[0]]],[p[1] for p in shape+[shape[0]]],color='#9bb0bd',lw=1.5)
    section.axhline(0,color='#75b8ce',lw=1,ls='--');section.text(-42,.5,'Waterline',fontsize=8,color='#75b8ce')
    for s in data['spaces']:
        a,b,c,d,e,f=s['bounds'];cat=s['category']
        if e<=z<=f:section.add_patch(Rectangle((a,c),b-a,d-c,facecolor=PALETTE[cat],edgecolor=bg,lw=.6,alpha=.88))
    a,b,c,d,e,f=hangar
    section.add_patch(Rectangle((a,c),b-a,d-c,facecolor='none',edgecolor=PALETTE['hangar'],lw=1.2,ls='--'))
    for s in data['parking_slots']:
        a,b,c,d,e,f=s['bounds']
        if e<=z<=f:section.add_patch(Rectangle((a,c),b-a,d-c,facecolor=PALETTE['aircraft'],edgecolor=bg,lw=.8))
    section.set(xlim=(-44,44),ylim=(-12.5,24),xlabel='Transverse position X (m)',ylabel='Height Y (m)')
    section.set_aspect('equal');section.set_title('Actual hull section at forward lift · Z = +54 m',loc='left',fontsize=12,pad=12)
    notes.set_facecolor(bg);notes.axis('off')
    notes.text(0,1,'SPACE RESERVATIONS',fontweight='bold',fontsize=13,transform=notes.transAxes)
    lines=[('accommodation','5,800 planning berths / 151 room envelopes'),('hotel_service','Separate hotel, medical and workshop space'),('machinery','Machinery and auxiliary power zones'),('fuel','13,316.8 m³ gross aviation fuel reservation'),('magazine','Separated aviation magazine zones'),('lift','Four 22 × 26 m platforms with inboard trunks'),('weapon','25 defensive weapon / decoy wells'),('laser','Four laser spaces reserved; visual concepts')]
    for i,(cat,text) in enumerate(lines):
        y=.91-i*.075;notes.add_patch(Rectangle((0,y-.018),.025,.035,transform=notes.transAxes,color=PALETTE[cat]));notes.text(.045,y,text,fontsize=9,va='center',transform=notes.transAxes)
    notes.text(0,.23,'L: large folded 12 × 20.5 m\nU: compact/UAV 9 × 11 m · R: folded rotor 9 × 14 m\nShaded central strip: clear 6 m towing spine',fontsize=9,color=muted,linespacing=1.6,transform=notes.transAxes)
    notes.text(0,.03,'Reference packing and geometric containment pass.\nAircraft turns, flight-deck parking and the complete\n99-aircraft cycle still require testing.',fontsize=9,color=muted,linespacing=1.5,transform=notes.transAxes)
    fig.suptitle('AUSTRALIS 2030  /  v0.5.1 INTERNAL FIT',x=.07,ha='left',fontsize=21,fontweight='bold',y=.97)
    fig.text(.07,.918,'Native game hull measured directly · 370 m length · 82 m overall deck beam · original immersed hull retained',fontsize=11,color=muted)
    fig.text(.07,.035,'Concept general arrangement: coloured volumes reserve space. This is not a completed naval-architecture or structural assessment.',fontsize=10,color=muted)
    fig.subplots_adjust(left=.07,right=.97,top=.855,bottom=.115)
    fig.savefig(out/'australis_v0.5.1_internal_plan.png',dpi=160,facecolor=bg)
    fig.savefig(out/'australis_v0.5.1_internal_plan.svg',facecolor=bg)
    plt.close(fig)

def main():
    result=validate_arrangement(PACKAGE)
    data=json.loads((PACKAGE/'internal-arrangement.json').read_text())
    native,obj,ini=load_current_mesh();mesh=Mesh()
    for name,v,faces,mat in native.parts:
        if name in ('Hull','UnderwaterHull'):
            # Clip actual side triangles at the centreline. Omit horizontal
            # internal closure caps; retaining a whole straddling triangle
            # would produce false spikes along the cutaway opening.
            vertices=[];polygons=[]
            for f in faces:
                if np.ptp(v[f,1])<.0001:continue
                points=[]
                for a,b in zip(v[f],np.roll(v[f],-1,axis=0)):
                    if a[0]<=0:points.append(a)
                    if (a[0]<0<b[0]) or (b[0]<0<a[0]):points.append(a+(b-a)*(-a[0]/(b[0]-a[0])))
                if len(points)>=3:
                    offset=len(vertices);vertices.extend(points);polygons.append(list(range(offset,offset+len(points))))
            mesh.add('hull:'+name,vertices,polygons,'hull')
        if name=='Deck':
            outline=v[:18]
            for i,(a,b) in enumerate(zip(outline,np.roll(outline,-1,axis=0))):beam(mesh,f'hull:deck edge {i}',a,b,'hull')
    wire_box(mesh,'hangar:clear envelope',data['hangar_bounds_m'],'hangar')
    for s in data['spaces']:
        name=s['category']+':'+s['name']
        if s['category'] in ('lift','weapon','laser'):wire_box(mesh,name,s['bounds'],s['category'])
        else:box(mesh,name,s['bounds'],s['category'])
    for s in data['parking_slots']:box(mesh,'aircraft:'+s['name'],s['bounds'],'aircraft')
    out=ROOT/'australis-2030/internal-preview';(out/'previews').mkdir(parents=True,exist_ok=True);(out/'model').mkdir(exist_ok=True)
    drawing(data,HullEnvelope.from_obj(obj),out)
    viewer.category=lambda name:name.split(':',1)[0]
    template=viewer.TEMPLATE.replace('</style>','#deploy,#laserStatus,#deployCIWS,#ciwsStatus{display:none}\n</style>')
    template=template.replace('CURRENT FIVE-CATAPULT LAYOUT','v0.5.1 INTERNAL SPACE STUDY')
    template=template.replace('Three bow + two port-waist catapults. Four lifts and four vertical spots. Aircraft support: fixed-wing carrier aircraft, VTOL/STOL and helicopters.','Original game hull with internal space reservations. Port hull retained; starboard side and flight deck removed to inspect the interior.')
    template=template.replace('These views and the rotatable model use the same current mesh. Aircraft are selected in Sea Power; this model has no parked aircraft.','Coloured boxes are planning envelopes, including 36 folded reference parking spaces. They are not detailed aircraft, cabins or machinery.')
    layers='\n'.join(f'<label><input type="checkbox" value="{key}" checked>{label}</label>' for key,label in LABELS.items())
    template=re.sub(r'<div id="layers">.*?</div>','<div id="layers">'+layers+'</div>',template,flags=re.S)
    template=re.sub(r'<div class="footer muted">.*?</aside>','<div class="footer muted">Measured native hull with original planning overlays. All reserved volumes clear the shell. Naval architecture, actual aircraft towing, lift animation and the 99-aircraft deck cycle remain unverified.</div>\n</aside>',template,flags=re.S)
    template=template.replace('Defensive mount study','Planning overlays').replace('Deployment demonstration only. The viewer does not fire weapons.','Toggle layers to inspect shafts, rooms, plant and tank reservations.')
    viewer.TEMPLATE=template
    revision=viewer.model_revision(mesh,PALETTE);photos=[]
    for name,title,az,el in [('cutaway','Internal reservations — starboard cutaway',-57,25),('plan','Hangar reference parking — top',None,None)]:
        path=out/'previews'/f'australis_v0.5.1_{name}.png'
        _render(list(mesh.triangles()),PALETTE,title,az,el,revision,path,
                caption='Actual native port hull + internal planning volumes · v0.5.1',
                footer='Reference space blockout · aircraft/cabins/plant are coloured envelopes · not a gameplay screenshot')
        photos.append({'id':name,'title':title,'caption':'Original native hull and labelled internal reservations; layers can be hidden in the rotatable view.','path':path})
    path=out/'viewer/australis_v0.5.1_internal_cutaway.html'
    viewer.build_viewer(mesh,PALETTE,path,photos=photos)
    manifest={'revision':revision,'origin':'Native game hull with clearly labelled conceptual space overlays','game_obj_sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'spaces':len(data['spaces']),'parking_slots':36,'validation':result}
    (out/'model/internal-preview-provenance.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('[OK]',path)

if __name__=='__main__':main()
