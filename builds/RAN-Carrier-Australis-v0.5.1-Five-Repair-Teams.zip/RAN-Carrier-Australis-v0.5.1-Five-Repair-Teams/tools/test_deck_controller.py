#!/usr/bin/env python3
import argparse, pathlib, subprocess, tempfile, json
p=argparse.ArgumentParser();p.add_argument('--sdk',type=pathlib.Path,required=True);a=p.parse_args();sdk=a.sdk.resolve();home=sdk.parent;root=pathlib.Path(__file__).resolve().parents[1]
csc=sorted(home.glob('sdk/*/Roslyn/bincore/csc.dll'))[-1]
ref=sorted(home.glob('packs/Microsoft.NETCore.App.Ref/*/ref/net8.0'))[-1]
with tempfile.TemporaryDirectory() as d:
 t=pathlib.Path(d);src=t/'PolicyTests.cs';src.write_text((root/'addon/DeckController/PolicyTests.cs.txt').read_text());exe=t/'PolicyTests.dll'
 args=['-nologo','-target:exe','-out:'+str(exe)]+['-r:'+str(r) for r in ref.glob('*.dll')]+[str(src),str(root/'addon/DeckController/DeckCycle.cs')]
 rsp=t/'args.rsp';rsp.write_text('\n'.join('"'+x+'"' for x in args));subprocess.run([str(sdk),str(csc),'@'+str(rsp)],check=True)
 (t/'PolicyTests.runtimeconfig.json').write_text(json.dumps({'runtimeOptions':{'tfm':'net8.0','framework':{'name':'Microsoft.NETCore.App','version':'8.0.15'}}}))
 subprocess.run([str(sdk),str(exe)],check=True)
