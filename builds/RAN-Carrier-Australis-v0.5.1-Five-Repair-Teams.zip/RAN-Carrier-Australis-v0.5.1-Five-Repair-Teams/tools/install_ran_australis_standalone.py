"""Self-contained installer entry point; the release script embeds its ZIP."""
import argparse, base64, contextlib, hashlib, io, json, os, shutil, sys, tempfile, zipfile
from datetime import datetime
from pathlib import Path

PAYLOAD = '__PAYLOAD__'
EXPECTED = '__SHA256__'
MOD = 'RAN-Carrier-Australis-2030'
DEFAULT = Path.home()/'.local/share/Steam/steamapps/common/Sea Power'

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def progress(n,s):print(f'[{n:3d}%] {s}',flush=True)
class Tee:
    def __init__(self,terminal,log):self.terminal,self.log=terminal,log
    def write(self,s):self.terminal.write(s);self.log.write(s);self.log.flush()
    def flush(self):self.terminal.flush();self.log.flush()

def main():
    parser=argparse.ArgumentParser(description='Install the independent Australis enclosed-deck prototype and its AnchorChain controller. Close Sea Power first.')
    parser.add_argument('--game',type=Path,default=DEFAULT)
    parser.add_argument('--log-dir',type=Path,default=Path.home()/'Downloads')
    parser.add_argument('--backups',type=Path,default=Path.home()/'Downloads/RAN-Carrier-Australis-2030-backups')
    parser.add_argument('--check',action='store_true',help='Check prerequisites/package without installing')
    parser.add_argument('--remove',action='store_true',help='Back up and withdraw only our mod and addon')
    args=parser.parse_args()
    if args.check and args.remove:parser.error('--check and --remove cannot be combined')
    downloads=args.log_dir.expanduser();downloads.mkdir(parents=True,exist_ok=True)
    logpath=downloads/('RAN-Australis-install-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.log')
    with logpath.open('w') as log,contextlib.redirect_stdout(Tee(sys.stdout,log)),contextlib.redirect_stderr(Tee(sys.stderr,log)):
        try:
            progress(0,'Australis enclosed-deck installer — experimental AnchorChain build')
            game=args.game.expanduser().resolve();assets=game/'Sea Power_Data/StreamingAssets'
            if not assets.is_dir() or assets.is_symlink():raise ValueError('Sea Power StreamingAssets not found: '+str(assets))
            for comm in Path('/proc').glob('[0-9]*/comm'):
                try:name=comm.read_text().strip().lower()
                except OSError:continue
                if name in ('sea power.exe','seapower.exe','sea power','seapower'):raise ValueError('Close Sea Power before running this installer.')
            progress(10,'Game location: '+str(game))
            data=base64.b64decode(PAYLOAD)
            if hashlib.sha256(data).hexdigest()!=EXPECTED:raise ValueError('Embedded package checksum failed; download the installer again.')
            with tempfile.TemporaryDirectory(prefix='ran-australis-installer-') as temp:
                temp=Path(temp)
                with zipfile.ZipFile(io.BytesIO(data)) as z:
                    for entry in z.infolist():
                        p=Path(entry.filename)
                        if p.is_absolute() or '..' in p.parts or (entry.external_attr>>16)&0o170000==0o120000:raise ValueError('Unsafe archive entry')
                    if z.testzip():raise ValueError('Embedded archive integrity check failed')
                    z.extractall(temp)
                roots=list(temp.iterdir())
                if len(roots)!=1 or not roots[0].is_dir():raise ValueError('Unexpected package layout')
                root=roots[0];manifest=json.loads((root/'BUILD-MANIFEST.json').read_text())
                for path,h in manifest['sha256_files'].items():
                    if digest(root/path)!=h:raise ValueError('Package file checksum failed: '+path)
                progress(25,f"Verified {len(manifest['sha256_files'])} package files")
                sys.path.insert(0,str(root/'tools'))
                import install_enclosed_deck as install
                from install_australis_2030 import fingerprints,backup_existing
                from validate_australis_2030_mod import main as validate
                backups=args.backups.expanduser()
                if backups.resolve().is_relative_to(game):raise ValueError('Backups must be outside the game folder')
                if args.remove:
                    install.install(game,backups,True)
                    progress(100,'Withdrawn our carrier/addon; verified backups retained')
                    return 0
                managed=game/'Sea Power_Data/Managed/Seapower-Scripts.dll'
                if not managed.is_file() or digest(managed)!=install.AUDITED:raise ValueError('Game scripts version differs from the supported build. Nothing installed. Share this log and the current game version for review.')
                progress(35,'Game scripts compatibility check passed')
                if not list((game/'BepInEx/patchers').rglob('AnchorChain.Preloader.dll')) or not (game/'BepInEx/core/0Harmony.dll').is_file():
                    raise ValueError('AnchorChain preloader missing. Install official ACPreloader first: https://github.com/SeaPower-Modders/AnchorChain/releases — then run this script again.')
                workshop=game.parents[1]/'workshop/content/1286220/3380210757'
                if not list(workshop.rglob('AnchorChain.dll')) and not list(assets.rglob('AnchorChain.dll')):
                    raise ValueError('AnchorChain framework missing. Subscribe to Workshop 3380210757: https://steamcommunity.com/sharedfiles/filedetails/?id=3380210757')
                progress(45,'AnchorChain preloader, Harmony and framework files found (runtime loading still needs verification)')
                package=root/'game-mod'/MOD
                validate(package,assets/'original')
                progress(60,'Carrier, aircraft routes, ammunition references and enclosed-bay transforms validated')
                target=assets/MOD;addon=assets/install.DLL
                if target.is_symlink() or addon.is_symlink():raise ValueError('Refusing a linked carrier/addon target')
                if args.check:
                    progress(100,'Checks passed; no game files changed')
                    return 0
                # Preflight completes before withdrawing a previous carrier.
                old=fingerprints(target) if target.exists() else None
                previous_dll=addon.read_bytes() if addon.exists() else None
                saved=None;rollback=None
                if old is not None and old!=fingerprints(package):
                    saved=backup_existing(target,backups)
                    progress(70,'Verified previous-carrier backup: '+str(saved))
                    rollback=Path(tempfile.mkdtemp(prefix='.ran-rollback-',dir=assets))/'carrier'
                    target.rename(rollback)
                completed=False
                try:
                    install.install(game,backups,False)
                    if fingerprints(target)!=fingerprints(package):raise ValueError('Installed carrier hash verification failed')
                    if digest(addon)!=digest(root/'addon/bin'/install.DLL):raise ValueError('Installed addon hash verification failed')
                    completed=True
                except BaseException:
                    if rollback is not None:
                        if target.exists():shutil.rmtree(target)
                        rollback.rename(target)
                    elif old is None and target.exists():shutil.rmtree(target)
                    if previous_dll is None:addon.unlink(missing_ok=True)
                    else:addon.write_bytes(previous_dll)
                    print('[ROLLBACK] Restored the previous carrier/addon state; backups retained.')
                    raise
                finally:
                    if rollback is not None and rollback.parent.exists() and (completed or not rollback.exists()):shutil.rmtree(rollback.parent)
                progress(95,'Installed carrier and compiled controller verified')
                print('[UNCHANGED] RADF, Workshop, original game files and User Data')
                print('[NEXT] Enable AnchorChain and RAN Australis in Mod Manager; restart Sea Power.')
                print('[NEXT] New blank mission: Australia > CVN > Australis. Air group starts empty.')
                print('[CHECK] StreamingAssets/RAN-Australis-DeckController.log must show Installed 15 audited hooks and Bound 75 enclosed-bay transforms.')
                print('[LIMIT] Runtime combat, animation and flight-lock testing remain pending. Lasers/Nulka remain visual concepts.')
                progress(100,'Installation complete')
                return 0
        except Exception as e:
            print('[STOP] '+str(e));print('[HELP] Copy this log back into chat for troubleshooting.')
            return 1
        finally:print('[LOG] '+str(logpath))

if __name__=='__main__':sys.exit(main())
