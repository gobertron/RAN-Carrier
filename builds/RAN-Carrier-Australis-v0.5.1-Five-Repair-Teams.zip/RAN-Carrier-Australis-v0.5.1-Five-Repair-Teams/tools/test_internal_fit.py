#!/usr/bin/env python3
"""Regression and deliberate-failure tests for actual hull containment."""
from pathlib import Path
import copy,json,tempfile,zipfile,hashlib
from internal_fit import HullEnvelope,validate_arrangement
ROOT=Path(__file__).resolve().parents[1]
PACKAGE=ROOT/'game-mod/RAN-Carrier-Australis-2030'
OBJ='ships/ran_cvn_australis_2030/ran_cvn_australis_2030.obj'

def main():
    result=validate_arrangement(PACKAGE)
    layout=json.loads((PACKAGE/'internal-arrangement.json').read_text())
    assert layout['game_obj_sha256']==hashlib.sha256((PACKAGE/OBJ).read_bytes()).hexdigest()
    tests=1
    with tempfile.TemporaryDirectory() as temporary:
        temp=Path(temporary)
        def refused(data,obj=PACKAGE/OBJ):
            nonlocal tests
            (temp/'internal-arrangement.json').write_text(json.dumps(data))
            try:validate_arrangement(temp,obj)
            except AssertionError:tests+=1
            else:raise AssertionError('Invalid arrangement was accepted')
        bad=copy.deepcopy(layout)
        lift=next(v for v in bad['spaces'] if v['category']=='lift')
        lift['bounds'][1]+=4;refused(bad)
        bad=copy.deepcopy(layout)
        well=next(v for v in bad['spaces'] if v['name']=='PVLS_2 well')
        well['bounds'][2]=4.6;refused(bad)
        bad=copy.deepcopy(layout)
        room=next(v for v in bad['spaces'] if v['category']=='accommodation')
        room['berths']+=1;refused(bad)
        bad=copy.deepcopy(layout)
        bad['parking_slots'][0]['bounds']=next(v['bounds'] for v in bad['spaces'] if v['category']=='lift')
        refused(bad)
        bad=copy.deepcopy(layout)
        fuel=next(v for v in bad['spaces'] if v['category']=='fuel')
        fuel['volume_m3']=1000;refused(bad)
        # The previous hull really fails the new test. This is not merely
        # an assertion that duplicated generator coordinates agree.
        baseline=ROOT/'builds/RAN-Carrier-Australis-v0.4.0-Helipad-Clearance.zip'
        with zipfile.ZipFile(baseline) as archive:
            name=next(n for n in archive.namelist() if n.endswith('/'+OBJ))
            old=temp/'old.obj';old.write_bytes(archive.read(name))
        h=HullEnvelope.from_obj(old)
        lifts=[v for v in layout['spaces'] if v['category']=='lift']
        assert h.margin(lifts[0]['bounds'])<0 and h.margin(lifts[3]['bounds'])<0
        tests+=1
        # Preserve the actual underwater mesh rather than just the stated
        # length/draft: v0.4.0 batched this first in Surface_Underwater.
        def vertices(path,name,count=None):
            found=[];active=False
            for line in path.read_text().splitlines():
                if line.startswith('o '):active=line[2:]==name
                elif active and line.startswith('v '):found.append(tuple(map(float,line.split()[1:])))
            return found[:count] if count else found
        assert vertices(old,'Surface_Underwater',34)==vertices(PACKAGE/OBJ,'UnderwaterHull')
        tests+=1
    print(f'[OK] {tests} internal-fit checks: new hull passes, original failures reproduced, malformed layouts refused, underwater mesh unchanged')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
