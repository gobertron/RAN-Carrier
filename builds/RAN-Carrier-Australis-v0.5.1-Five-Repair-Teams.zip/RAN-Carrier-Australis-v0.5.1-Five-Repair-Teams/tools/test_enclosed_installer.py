#!/usr/bin/env python3
"""Reversible integration test against a disposable mock game tree.

The audited game DLL is read locally for version pinning, never distributed.
"""
import argparse,configparser,contextlib,hashlib,io,shutil,tempfile
from pathlib import Path
import install_enclosed_deck as installer
from install_australis_2030 import fingerprints,run,MOD_NAME
p=argparse.ArgumentParser();p.add_argument('--game-dll',type=Path,required=True);a=p.parse_args()
assert installer.sha(a.game_dll)==installer.AUDITED
with tempfile.TemporaryDirectory() as temp:
 base=Path(temp);game=base/'steamapps/common/Sea Power';assets=game/'Sea Power_Data/StreamingAssets';orig=assets/'original';orig.mkdir(parents=True)
 (orig/'vessels').mkdir();(orig/'vessels/usn_cvn_nimitz.ini').write_text('; mock stock reference')
 cfg=configparser.ConfigParser(interpolation=None);cfg.optionxform=str
 cfg.read(installer.ROOT/f'game-mod/{MOD_NAME}/vessels/ran_cvn_australis_2030.ini',encoding='utf-8-sig')
 (orig/'systems').mkdir();(orig/'ammunition').mkdir()
 for family,file in [('SensorSystem','sensors.ini'),('WeaponSystem','weapons.ini')]:
  names={cfg[s]['SystemName'] for s in cfg.sections() if s.startswith(family) and s[len(family):].isdigit() and cfg[s]['Type']!='Visual'}
  (orig/'systems'/file).write_text('\n'.join('['+n+']' for n in sorted(names)))
 for sec in cfg.values():
  for key,value in sec.items():
   if key=='Countermeasure' or key.startswith('Ammunition') and (key=='Ammunition' or key[10:].isdigit()):
    (orig/'ammunition'/(value+'.ini')).write_text('; mock ammunition')
 managed=game/'Sea Power_Data/Managed';managed.mkdir();shutil.copy2(a.game_dll,managed/'Seapower-Scripts.dll')
 backups=base/'backups';stock_before=fingerprints(orig)
 try:installer.install(game,backups)
 except FileNotFoundError:pass
 else:raise AssertionError('Missing framework accepted')
 assert not (assets/MOD_NAME).exists() and not (assets/installer.DLL).exists()
 patch=game/'BepInEx/patchers/AnchorChain';patch.mkdir(parents=True);(patch/'AnchorChain.Preloader.dll').write_bytes(b'mock')
 core=game/'BepInEx/core';core.mkdir();(core/'0Harmony.dll').write_bytes(b'mock')
 ac=base/'steamapps/workshop/content/1286220/3380210757';ac.mkdir(parents=True);(ac/'AnchorChain.dll').write_bytes(b'mock')
 protected_before=fingerprints(ac)
 try:run(game,installer.ROOT/'game-mod'/MOD_NAME,backups,False)
 except ValueError:pass
 else:raise AssertionError('Unpaired native installer accepted enclosed package')
 with contextlib.redirect_stdout(io.StringIO()):
  installer.install(game,backups)
  assert fingerprints(assets/MOD_NAME)==fingerprints(installer.ROOT/'game-mod'/MOD_NAME)
  assert installer.sha(assets/installer.DLL)==installer.sha(installer.ROOT/'addon/bin'/installer.DLL)
  installer.install(game,backups) # Idempotent
  installer.install(game,backups,True)
 assert not (assets/MOD_NAME).exists() and not (assets/installer.DLL).exists()
 assert fingerprints(orig)==stock_before and fingerprints(ac)==protected_before
 assert list(backups.rglob(installer.DLL)) and list(backups.rglob('_info.ini'))
 print('PASS installer: dependency refusal, paired addon gate, verified install, idempotence, removal, retained backups, stock/Workshop unchanged')
