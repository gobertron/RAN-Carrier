#!/usr/bin/env python3
"""Install/withdraw this experimental carrier and its own AnchorChain addon.

Only our standalone carrier folder and named addon DLL are changed. Framework
installation stays with official AnchorChain; stock/Workshop/RADF are read only.
"""
import argparse, hashlib, shutil, tempfile
from datetime import datetime, timezone
from pathlib import Path
from install_australis_2030 import run, DEFAULT_GAME, DEFAULT_BACKUPS, MOD_NAME
ROOT=Path(__file__).resolve().parents[1]
DLL='RAN.Australis.DeckController.dll'
AUDITED='3b193dcb71fcbae2f8ede15484223b139948e2b9bd3ae66fc7d45db104350297'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def backup_dll(target,backups):
    if target.is_symlink():raise ValueError('Refusing a linked addon DLL')
    if not target.exists():return None
    folder=backups/('addon-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f'));folder.mkdir(parents=True)
    dst=folder/DLL;shutil.copy2(target,dst)
    if sha(dst)!=sha(target):raise ValueError('Addon backup verification failed')
    print('[BACKUP] '+str(dst));return dst

def install(game,backups,remove=False):
    assets=game/'Sea Power_Data/StreamingAssets';target=assets/DLL
    if not assets.is_dir() or assets.is_symlink():raise FileNotFoundError('StreamingAssets not found')
    if backups.resolve().is_relative_to(game.resolve()):raise ValueError('Backups must be outside the game')
    if remove:
        # Withdraw the mod first, retaining the controller if removal fails.
        run(game,ROOT/'game-mod'/MOD_NAME,backups,True)
        old=backup_dll(target,backups)
        if old:target.unlink();print('[OK] Withdrew our AnchorChain addon')
        return
    source=ROOT/'addon/bin'/DLL
    if not source.is_file():raise FileNotFoundError('Compiled controller is missing; use the complete Enclosed-Deck ZIP')
    managed=game/'Sea Power_Data/Managed/Seapower-Scripts.dll'
    if not managed.is_file() or sha(managed)!=AUDITED:
        raise ValueError('This game scripts DLL does not match the audited version. No files changed. Supply the current DLL for hook review before using this experimental addon.')
    preloader=game/'BepInEx/patchers/AnchorChain.Preloader.dll'
    if not list((game/'BepInEx/patchers').rglob('AnchorChain.Preloader.dll')) or not (game/'BepInEx/core/0Harmony.dll').is_file():
        raise FileNotFoundError('Install the official AnchorChain ACPreloader first: https://github.com/SeaPower-Modders/AnchorChain/releases . Then subscribe to and enable AnchorChain Workshop 3380210757. No files changed.')
    workshop=game.parents[1]/'workshop/content/1286220/3380210757'
    if not list(workshop.rglob('AnchorChain.dll')) and not list(assets.rglob('AnchorChain.dll')):
        raise FileNotFoundError('AnchorChain framework not found. Subscribe to Workshop 3380210757 and enable it. No files changed.')
    if target.is_symlink():raise ValueError('Refusing a linked addon DLL')
    existing=target.read_bytes() if target.exists() else None
    old=backup_dll(target,backups)
    try:
        with tempfile.NamedTemporaryFile(dir=assets,prefix='.ran-addon-',delete=False) as f:
            stage=Path(f.name);f.write(source.read_bytes())
        if sha(stage)!=sha(source):raise ValueError('Addon staging verification failed')
        stage.replace(target)
        run(game,ROOT/'game-mod'/MOD_NAME,backups,False)
    except Exception:
        if existing is None:target.unlink(missing_ok=True)
        else:target.write_bytes(existing)
        raise
    finally:
        if 'stage' in locals():stage.unlink(missing_ok=True)
    print('[OK] Controller installed; enable AnchorChain and the Australis mod, restart Sea Power.')
    print('[CHECK] StreamingAssets/RAN-Australis-DeckController.log must report Installed 15 audited hooks.')
    print('[LIMIT] Experimental: first in-game combat and flight-lock verification is still required.')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--game',type=Path,default=DEFAULT_GAME);p.add_argument('--backups',type=Path,default=DEFAULT_BACKUPS);p.add_argument('--remove',action='store_true');a=p.parse_args()
    try:install(a.game.expanduser(),a.backups.expanduser(),a.remove)
    except (OSError,ValueError,AssertionError) as e:raise SystemExit('[STOP] '+str(e))
