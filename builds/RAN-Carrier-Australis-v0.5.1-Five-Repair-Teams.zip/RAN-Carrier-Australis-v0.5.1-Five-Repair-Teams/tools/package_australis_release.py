#!/usr/bin/env python3
"""Create an immutable numbered carrier/controller installer and source bundle."""
from pathlib import Path
import base64,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
sha=lambda value:hashlib.sha256(value).hexdigest()

def main():
    version=(ROOT/'VERSION').read_text().strip()
    assert version=='0.5.1','Choose a new release label before packaging another revision'
    label=f'RAN-Carrier-Australis-v{version}-Five-Repair-Teams'
    builds=ROOT/'builds';archive=builds/(label+'.zip');standalone=builds/f'install-ran-australis-v{version}.sh'
    if archive.exists() or standalone.exists():raise FileExistsError('Numbered releases are immutable; increment VERSION for another release')
    native=json.loads((ROOT/'australis-2030/current-game-preview/model/game-preview-provenance.json').read_text())
    internal=json.loads((ROOT/'australis-2030/internal-preview/model/internal-preview-provenance.json').read_text())
    package=ROOT/'game-mod/RAN-Carrier-Australis-2030'
    obj=package/'ships/ran_cvn_australis_2030/ran_cvn_australis_2030.obj'
    ini=package/'vessels/ran_cvn_australis_2030.ini'
    assert sha(obj.read_bytes())==native['obj_sha256']==internal['game_obj_sha256']
    assert sha(ini.read_bytes())==native['ini_sha256']
    files=list(package.rglob('*'))+list((ROOT/'addon').rglob('*'))
    files += [ROOT/n for n in ('VERSION','README.md','CHANGELOG.md','generate_source_models.py','rebuild_game_scale.py')]
    files += list((ROOT/'australis-2030').glob('*.py'))
    files += list((ROOT/'australis-2030/model/source').glob('*'))
    files += list((ROOT/'australis-2030/model/game-scale').glob('*'))
    files += [ROOT/'australis-2030/model/validation.json']
    files += [ROOT/'australis-2030'/n for n in ('spec.json','README.md','SHIP.md','DESIGN-BASIS.md','INTERNAL-FIT.md','GAME-TEST.md','viewer/australis_2030_3d.html','current-game-preview/model/game-preview-provenance.json')]
    files += list((ROOT/'australis-2030/current-game-preview/previews').glob('*.png'))
    files += [ROOT/'australis-2030/internal-preview'/n for n in ('viewer/australis_v0.5.1_internal_cutaway.html','model/internal-preview-provenance.json','australis_v0.5.1_internal_plan.png','australis_v0.5.1_internal_plan.svg')]
    files += list((ROOT/'australis-2030/internal-preview/previews').glob('australis_v0.5.1_*.png'))
    files += [ROOT/'tools'/n for n in ('install_enclosed_deck.py','install_australis_2030.py','install_ran_australis_standalone.py','validate_australis_2030_mod.py','internal_fit.py','build_australis_2030_mod.py','build_internal_arrangement.py','build_internal_cutaway.py','build_current_game_preview.py','build_deck_controller.py','test_internal_fit.py','test_deck_controller.py','test_enclosed_installer.py','package_australis_release.py')]
    files=sorted({p for p in files if p.is_file() and '__pycache__' not in p.parts})
    manifest={'build':label,'version':version,'source_base_commit':'005fd729dd7b20be09f1958d7af78bb7a93be7f0',
              'model_revision':native['revision'],'cutaway_revision':internal['revision'],
              'publication':'Prepared for gobertron/RAN-Carrier on feature/australis-2050-concept',
              'anchorchain_required':True,'in_game_tested':False,'internal_fit':internal['validation'],
              'sha256_files':{p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in files}}
    temporary=archive.with_suffix('.staged.zip')
    with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:z.writestr(label+'/'+p.relative_to(ROOT).as_posix(),p.read_bytes())
        z.writestr(label+'/BUILD-MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(temporary) as z:
        assert z.testzip() is None
        for name,digest in manifest['sha256_files'].items():assert sha(z.read(label+'/'+name))==digest,name
    temporary.replace(archive)
    stub=(ROOT/'tools/install_ran_australis_standalone.py').read_text()
    stub=stub.replace('__PAYLOAD__',base64.b64encode(archive.read_bytes()).decode()).replace('__SHA256__',sha(archive.read_bytes()))
    stub=stub.replace('Australis enclosed-deck installer — experimental AnchorChain build',f'Australis v{version} — five repair teams and independent carrier installer')
    standalone.write_text('#!/usr/bin/env bash\nset -euo pipefail\ncommand -v python3 >/dev/null || { echo "Python 3 is required"; exit 1; }\npython3 - "$@" <<\'RAN_INSTALLER_PY\'\n'+stub+'\nRAN_INSTALLER_PY\n')
    standalone.chmod(0o755)
    manifest.update(archive_sha256=sha(archive.read_bytes()),archive_size_bytes=archive.stat().st_size,
                    installer_sha256=sha(standalone.read_bytes()))
    (builds/(label+'-manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n')
    release={'version':version,'previous_version':'0.5.0','change':'Five native repair teams and dedicated ship page',
             'model_revision':native['revision'],'cutaway_revision':internal['revision'],'in_game_tested':False,
             'github_publication':'Prepared for gobertron/RAN-Carrier; publication checked separately',
             'artifacts':{archive.name:sha(archive.read_bytes()),standalone.name:sha(standalone.read_bytes())}}
    (builds/f'Australis-v{version}-release.json').write_text(json.dumps(release,indent=2)+'\n')
    print(f'[OK] {archive.name}: {archive.stat().st_size} bytes, {len(files)} verified files')
    print('[OK]',standalone)

if __name__=='__main__':main()
